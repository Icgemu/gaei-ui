import React from 'react';
export default [
    {
        label: 'Master',
        value: 'Master',
        items: [
            {
                label: 'Eugenia',
                title: 'Eugenia',
                value: 'Eugenia'
            },
            {
                label: 'Kariane-Kariane-Kariane-Kariane-Kariane KarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKarianeKariane KarianeKarianeKarianeKariane',
                value: 'Kariane'
            },
            {
                label: 'Louisa',
                value: 'Louisa'
            },
            {
                label: 'Marty',
                value: 'Marty'
            },
            {
                label: 'Kenya',
                value: 'Kenya'
            }
        ]
    },
    {
        label: 'Developer',
        value: 'Developer',
        items: [
            {
                label: 'Hal',
                value: 'Hal'
            },
            {
                label: 'Julius',
                value: 'Julius'
            },
            {
                label: 'Travon',
                value: 'Travon'
            },
            {
                label: 'Vincenza',
                value: 'Vincenza'
            },
            {
                label: 'Dominic',
                value: 'Dominic'
            }
        ]
    },
    {
        label: 'Reporter',
        value: 'Reporter',
        items: [
            {
                label: 'Dave',
                value: 'Dave'
            },
            {
                label: 'Maya',
                value: 'Maya'
            },
            {
                label: 'Kristoffer',
                value: 'Kristoffer'
            }
        ]
    },
    {
        label: 'Guest',
        value: 'Guest',
        items: [
            {
                label: 'Pearlie',
                value: 'Pearlie'
            },
            {
                label: 'Tyrel',
                value: 'Tyrel'
            },
            {
                label: 'Jaylen',
                value: 'Jaylen'
            },
            {
                label: 'Rogelio',
                value: 'Rogelio'
            }
        ]
    }
];
