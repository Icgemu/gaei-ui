import common from './common';

export default {
    ...common
};
