export default {
    Github: 'Github',
    Events: 'Events',
    Repos: 'Repos',
    noDataFound: 'No Data Found',
    loading: 'loading'
};
