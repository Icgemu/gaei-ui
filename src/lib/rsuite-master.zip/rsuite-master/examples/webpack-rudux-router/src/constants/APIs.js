export const API_EVENTS = 'https://api.github.com/users/rsuite/received_events';
export const API_REPOS = 'https://api.github.com/users/rsuite/repos';
