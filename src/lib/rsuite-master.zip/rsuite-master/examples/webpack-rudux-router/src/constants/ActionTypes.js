export const FETCH_EVENTS = 'FETCH_EVENTS';
export const FETCH_REPOS = 'FETCH_REPOS';
