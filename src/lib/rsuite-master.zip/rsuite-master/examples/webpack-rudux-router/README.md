# example

[http://rsuite.github.io/examples/webpack-rudux-router/](http://rsuite.github.io/examples/webpack-rudux-router/)
