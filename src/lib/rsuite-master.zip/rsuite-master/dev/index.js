import React from 'react';
import ReactDOM from 'react-dom';
import ButtonGroupDemo from './ButtonGroupDemo';

ReactDOM.render(<ButtonGroupDemo/>, document.getElementById('mount'));
