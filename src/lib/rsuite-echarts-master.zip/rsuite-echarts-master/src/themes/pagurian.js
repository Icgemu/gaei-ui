import echarts from 'echarts';

echarts.registerTheme('pagurian', {
    backgroundColor: '#f5f5f5',
    color: ['#fe8463', '#9bca63', '#fad860', '#60c0dd', '#0084c6', '#d7504b', '#c6e579', '#26c0c0', '#f0805a', '#f4e001', '#b5c334']
});
