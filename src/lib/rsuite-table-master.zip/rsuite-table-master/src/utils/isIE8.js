module.exports = !!navigator.userAgent.match(/MSIE 8.0/);
